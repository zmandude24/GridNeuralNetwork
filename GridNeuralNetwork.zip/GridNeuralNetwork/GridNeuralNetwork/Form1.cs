﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

/* Test Grid Schematic Diagram:
 * 
 *                   <- I1-0    I1-3 ->
 *                  --------(1)-----------------
 *                  |        |                 |
 *                ( + )      |  I1-2           |
 *               (     )     |  |              |
 *                ( - )      |  \/             |
 *                  |        |                 |
 *                 ===       |                 |
 *                  =        |                 |
 *                           |                 |
 *                          (2)               (3)
 *                       [       ]         [       ]
 *                       [ Load  ]         [ Load  ]
 *                       [       ]         [       ]
 *                           |                 |
 *                          ===               ===
 *                           =                 =
 */
/// This program predicts the status of a line based on the current flowing through the line, the 
/// voltages of the nodes it's connected to, and the other currents flowing out of said nodes using
/// a knn neural network for each line. Currently, a very simple three node testing grid with a power
/// source and two loads is used, but this can predict the output for any single phase DC grid
/// regardless of complexity when given the inputs in the correct format.
namespace GridNeuralNetwork
{
    public partial class Form : System.Windows.Forms.Form
    {
        /* For the test case:                                       *
         * [I1-0 samples, I1-2 samples, I2-0 samples, I3-0 samples] */
        private List<List<Line>> trainingList;  // The list of sample lists with each line
                                                            // to base predictions on
        private List<Line> testList;    // The list of samples for each line to be predicted


        public Form()
        {
            InitializeComponent();
        }


        /// <summary>
        /// This method creates data for the training and test lists when the form is loaded.
        /// </summary>
        private void Form_Load(object sender, EventArgs e)
        {
            NewTestData();
        }


        /// <summary>
        /// This method calls PrintTrainingList() when buttonPrintTrainingList is clicked.
        /// </summary>
        private void buttonPrintTrainingList_Click(object sender, EventArgs e)
        {
            PrintTrainingList();
        }

        /// <summary>
        /// This method prints the phasor training list line cases.
        /// </summary>
        private void PrintTrainingList()
        {
            textBox.Clear();
            textBox.Text = "Training Lists: " + "\r\n";
            for (int listIndex = 0; listIndex < trainingList.Count; listIndex++)
            {
                string[] text = GNN_Methods.PrintLineList(trainingList[listIndex]);
                textBox.Text += "Sample #" + (listIndex + 1).ToString() + "\r\n";
                for (int textIndex = 0; textIndex < text.Length; textIndex++)
                {
                    textBox.Text += text[textIndex];

                    // Every line except the last one
                    if ((listIndex < trainingList.Count - 1) || (textIndex < text.Length - 1))
                        textBox.Text += "\r\n";
                }
            }
        }


        /// <summary>
        /// This method calls PrintTestList when buttonPrintTestList is pressed.
        /// </summary>
        private void buttonPrintTestList_Click(object sender, EventArgs e)
        {
            PrintTestList();
        }

        /// <summary>
        /// This method prints the test cases to the textbox.
        /// </summary>
        private void PrintTestList()
        {
            textBox.Clear();
            textBox.Text = "Test List: " + "\r\n";
            string[] text = GNN_Methods.PrintLineList(testList);
            for (int lineIndex = 0; lineIndex < text.Length; lineIndex++)
            {
                textBox.Text += text[lineIndex];
                if (lineIndex < text.Length - 1) textBox.Text += "\r\n";
            }
        }


        /// <summary>
        /// This method calls TestDemoListLine12() when buttonTestLine12Demo is clicked.
        /// </summary>
        private void buttonTestLine12Demo_Click(object sender, EventArgs e)
        {
            TestDemoListLine12();
        }

        /// <summary>
        /// This method does the following:
        /// 1. Create the list of training cases for line 1-2 from the training list.
        /// 2. Use those lines to find the closest neighbors to the test case.
        /// 3. Predict the status from the majority of the nearest neighbors.
        /// 4. Print the nearest neighbor cases with the distance to the test case as well as
        ///     the predicted and actual statuses of the test case.
        /// </summary>
        private void TestDemoListLine12()
        {
            List<Line> lines = new List<Line>();
            for (int row = 0; row < trainingList.Count; row++)
                lines.Add(trainingList[row][1]);    // instances of line 1-2 are in column index 1

            // This is the list of lines with the addition of a distance parameter for each element.
            List<Distance> knn = GNN_Methods.GetKNN_List(lines, testList[1], 3);

            string[] text = GNN_Methods.PrintDistanceList(knn);
            textBox.Clear();
            for (int row = 0; row < text.Length; row++)
                textBox.Text += text[row] + "\r\n";
            textBox.Text += "Predicted Status: " + GNN_Methods.PredictOutput(knn).ToString() + "\r\n";
            textBox.Text += "Actual Status: " + testList[1].isLineWorking.ToString();
        }


        /// <summary>
        /// This method calls NewTestData() when buttonPrintTrainingList is clicked and also clears the
        /// textbox.
        /// </summary>
        private void buttonNewTestData_Click(object sender, EventArgs e)
        {
            NewTestData();
            textBox.Clear();
        }

        /// <summary>
        /// This method generates new cases for the training and test lists, and overwrites any
        ///     previous cases.
        /// </summary>
        private void NewTestData()
        {
            trainingList = GNN_Methods.DemoTrainingList();
            testList = GNN_Methods.DemoTestList();
        }
    }


    /// <summary>
    /// This is the data representation of a measurement such as voltage or current. There is a name,
    /// starting node, destination node, and the phasor value in base units.
    /// </summary>
    public class Measurement
    {
        public string name { get; set; }    // Va for voltage where a is the node number and
                                            //     Ia-b for current where a is the node number and b is
                                            //     the receiving node number.

        public int startNode { get; set; }  // starting node
        public int destNode { get; set; }   // destination node
        public PolarPhasor baseUnitValue { get; set; }  // in base units
    }


    /// <summary>
    /// This is the data representation of a node. Each node is given a unique number (0 means ground),
    /// the voltage measurement of the node to ground, and the currents coming out of the node sorted
    /// by which node they are going to (this can be ground).
    /// </summary>
    public class Node
    {
        public int num { get; set; }    // the number 0 means ground
        public Measurement nodeV { get; set; }    // the voltage at the node
        public List<Measurement> currentsFromNode { get; set; }   // currents going to other nodes
                                                                        // as well as ground
    }


    /// <summary>
    /// This is the data representation of a line of interest that contains the current on the line,
    /// the voltages of the nodes it connects, and the other currents coming out of each node. The 
    /// destination node will always have a higher number than the starting node (except for ground)
    /// to avoid duplicate lines with the starting and destination nodes inverted.
    /// </summary>
    public class Line
    {
        public Measurement lineCurrent { get; set; }    // the line current

        public Measurement startNodeV { get; set; }     // the starting node voltage
        public List<Measurement> otherCurrentsFromStartNode { get; set; }   // currents coming from
                                                        // the starting node excluding the line current

        public Measurement destNodeV { get; set; }      // the destination node voltage
        public List<Measurement> otherCurrentsFromDestNode { get; set; }    // currents coming from
                                    // the destination node excluding the negative of the line current

        public bool isLineWorking { get; set; }     // false could mean a fault or a disconnection
    }


    /// <summary>
    /// This is the line class with the parameter distance added. The distance is used to compare how
    /// close the line is to the test case.
    /// </summary>
    public class Distance : Line
    {
        public double distance { get; set; }    // a measure of how close the test case is to this line

        public Distance(Line phasorLine)
        {
            lineCurrent = phasorLine.lineCurrent;
            startNodeV = phasorLine.startNodeV;
            otherCurrentsFromStartNode = phasorLine.otherCurrentsFromStartNode;
            destNodeV = phasorLine.destNodeV;
            otherCurrentsFromDestNode = phasorLine.otherCurrentsFromDestNode;
            isLineWorking = phasorLine.isLineWorking;
        }
        public Distance() { }
    }


    /// <summary>
    /// This class contains methods for general use in the project.
    /// </summary>
    public static class GNN_Methods
    {
        /// <summary>
        /// This method creates a list of the nodes with their number, voltage, and currents flowing
        ///     from there.
        /// </summary>
        /// <param name="connections">
        /// connections (does the line exist): the left number is the starting node and the right
        ///     is the destination node.
        /// [x10 x11 ... x1n]
        /// [x20 x21 ... x2n]
        /// [      ...      ]
        /// [xn0 xn1 ... xnn]
        /// </param>
        /// <param name="voltages">
        /// voltages:
        /// [V1; V2; ... Vn]
        /// </param>
        /// <param name="currents">
        /// currents: the left number is the starting node and the right is the destination node.
        /// [I10 I11 ... I1n]
        /// [I20 I21 ... I2n]
        /// [      ...      ]
        /// [In0 In1 ... Inn]
        /// </param>
        /// <returns>
        /// The list of nodes
        /// </returns>
        public static List<Node> NodeList(bool[,] connections, PolarPhasor[] voltages,
            PolarPhasor[,] currents)
        {
            List<Node> nodeList = new List<Node>();

            for (int startNodeNum = 1; startNodeNum <= voltages.Length; startNodeNum++)
            {
                Node newNode = new Node();
                newNode.num = startNodeNum;

                Measurement V = new Measurement();
                V.name = "V" + startNodeNum.ToString();
                V.startNode = startNodeNum;
                V.destNode = 0;
                V.baseUnitValue = voltages[startNodeNum - 1];
                newNode.nodeV = V;

                newNode.currentsFromNode = new List<Measurement>();
                for (int destNodeNum = 0; destNodeNum <= voltages.Length; destNodeNum++)
                {
                    if (connections[startNodeNum - 1, destNodeNum])
                    {
                        Measurement otherCurrents = new Measurement();
                        otherCurrents.name = "I" + startNodeNum.ToString()
                            + "-" + destNodeNum.ToString();
                        otherCurrents.startNode = startNodeNum;
                        otherCurrents.destNode = destNodeNum;
                        otherCurrents.baseUnitValue = currents[startNodeNum - 1, destNodeNum];
                        newNode.currentsFromNode.Add(otherCurrents);
                    }
                }

                nodeList.Add(newNode);
            }

            return nodeList;
        }


        /// <summary>
        /// This method creates a string array with the nodes and their parameters that is to be printed
        ///     to the textbox.
        /// </summary>
        /// <param name="nodeList">
        /// The list of nodes to be printed
        /// </param>
        /// <returns>
        /// The string array to be printed to the textbox
        /// </returns>
        public static string[] PrintNodeList(List<Node> nodeList)
        {
            string[] text = new string[nodeList.Count];

            for (int nodeIdx = 0; nodeIdx < nodeList.Count; nodeIdx++)
            {
                text[nodeIdx] = "Node " + nodeList[nodeIdx].num + ": ";
                text[nodeIdx] += nodeList[nodeIdx].nodeV.name + " = "
                    + PhasorMethods.PrintPhasor(nodeList[nodeIdx].nodeV.baseUnitValue) + ", ";
                for (int crntIdx = 0; crntIdx < nodeList[nodeIdx].currentsFromNode.Count; crntIdx++)
                {
                    text[nodeIdx] += nodeList[nodeIdx].currentsFromNode[crntIdx].name + " = "
                        + PhasorMethods.PrintPhasor(
                            nodeList[nodeIdx].currentsFromNode[crntIdx].baseUnitValue);
                    if (crntIdx < nodeList[nodeIdx].currentsFromNode.Count - 1)
                        text[nodeIdx] += ", ";
                }
            }

            return text;
        }


        /// <summary>
        /// This method creates a list of lines from the list of nodes given with the
        ///     statuses of the lines.
        /// </summary>
        /// <param name="statuses">
        /// statuses (is the line working): the left number is the starting node and the right is the
        ///     destination node
        /// [x10 x11 ... x1n]
        /// [x20 x21 ... x2n]
        /// [      ...      ]
        /// [xn0 xn1 ... xnn]
        /// </param>
        /// <param name="nodes">
        /// The list of nodes
        /// </param>
        /// <returns>
        /// The list of lines
        /// </returns>
        public static List<Line> LineList(bool[,] statuses, List<Node> nodes)
        {
            List<Line> lineList = new List<Line>();

            for (int nodeIdx = 0; nodeIdx < nodes.Count; nodeIdx++)
            {
                for (int crntIdx = 0; crntIdx < nodes[nodeIdx].currentsFromNode.Count; crntIdx++)
                {
                    int startNodeNum = nodeIdx + 1;
                    int destNodeNum = nodes[nodeIdx].currentsFromNode[crntIdx].destNode;

                    // Don't add an identical line but with the starting and destination nodes flipped.
                    if ((destNodeNum == 0) || (destNodeNum > startNodeNum))
                    {
                        Line line = new Line();

                        line.lineCurrent = nodes[nodeIdx].currentsFromNode[crntIdx];

                        line.isLineWorking = statuses[nodeIdx, destNodeNum];

                        line.startNodeV = nodes[nodeIdx].nodeV;
                        line.otherCurrentsFromStartNode = new List<Measurement>();
                        foreach (Measurement current in nodes[nodeIdx].currentsFromNode)
                            if (current.destNode != destNodeNum)
                                line.otherCurrentsFromStartNode.Add(current);

                        // Special case if the current is going directly to ground
                        if (nodes[nodeIdx].currentsFromNode[crntIdx].destNode == 0)
                        {
                            line.destNodeV = new Measurement();
                            line.destNodeV.name = "GND";
                            line.destNodeV.startNode = 0;
                            line.destNodeV.destNode = 0;
                            line.destNodeV.baseUnitValue = new PolarPhasor(0, 0);
                            line.otherCurrentsFromDestNode = new List<Measurement>(); // the list
                                                                                            // stays empty
                        }

                        // Case where the current is going to another node
                        else
                        {
                            line.destNodeV = new Measurement();
                            line.destNodeV = nodes[destNodeNum - 1].nodeV;
                            line.otherCurrentsFromDestNode = new List<Measurement>();
                            foreach (Measurement Ik in nodes[destNodeNum - 1].currentsFromNode)
                                if (Ik.destNode != startNodeNum) line.otherCurrentsFromDestNode.Add(Ik);
                        }

                        lineList.Add(line);
                    }
                }
            }

            return lineList;
        }


        /// <summary>
        /// This method creates a string array with the lines and their parameters that is to be
        ///     printed to the textbox.
        /// </summary>
        /// <param name="lineList">
        /// A list of lines that is to be printed
        /// </param>
        /// <returns>
        /// The string array that is to be printed to the textbox
        /// </returns>
        public static string[] PrintLineList(List<Line> lineList)
        {
            string[] text = new string[lineList.Count];

            for (int lineIdx = 0; lineIdx < lineList.Count; lineIdx++)
            {
                text[lineIdx] += "Line " + lineList[lineIdx].startNodeV.startNode
                    + "-" + lineList[lineIdx].destNodeV.startNode + ": ";
                text[lineIdx] += "status: " + lineList[lineIdx].isLineWorking.ToString() + ", ";

                text[lineIdx] += lineList[lineIdx].lineCurrent.name + " = "
                    + PhasorMethods.PrintPhasor(lineList[lineIdx].lineCurrent.baseUnitValue) + ", ";
                text[lineIdx] += lineList[lineIdx].startNodeV.name + " = "
                    + PhasorMethods.PrintPhasor(lineList[lineIdx].startNodeV.baseUnitValue) + ", ";
                text[lineIdx] += lineList[lineIdx].destNodeV.name + " = "
                    + PhasorMethods.PrintPhasor(lineList[lineIdx].destNodeV.baseUnitValue) + ", ";

                for (int crntIdx = 0; crntIdx < lineList[lineIdx].otherCurrentsFromStartNode.Count;
                    crntIdx++)
                {
                    text[lineIdx] += lineList[lineIdx].otherCurrentsFromStartNode[crntIdx].name + " = "
                        + PhasorMethods.PrintPhasor(
                            lineList[lineIdx].otherCurrentsFromStartNode[crntIdx].baseUnitValue);
                    if (crntIdx < lineList[lineIdx].otherCurrentsFromStartNode.Count - 1)
                        text[lineIdx] += ", ";
                }

                for (int crntIdx = 0; crntIdx < lineList[lineIdx].otherCurrentsFromDestNode.Count;
                    crntIdx++)
                {
                    if (crntIdx == 0) text[lineIdx] += ", ";
                    text[lineIdx] += lineList[lineIdx].otherCurrentsFromDestNode[crntIdx].name + " = "
                        + PhasorMethods.PrintPhasor(
                            lineList[lineIdx].otherCurrentsFromDestNode[crntIdx].baseUnitValue);
                    if (crntIdx < lineList[lineIdx].otherCurrentsFromDestNode.Count - 1)
                        text[lineIdx] += ", ";
                }
            }

            return text;
        }

        /// <summary>
        /// This method creates a string array with a list of lines and their parameters which includes
        ///     their distance to the test case, which is to be printed to the textbox.
        /// </summary>
        /// <param name="distances">
        /// The list of lines with the distances.
        /// </param>
        /// <returns>
        /// The string array to be printed to the textbox.
        /// </returns>
        public static string[] PrintDistanceList(List<Distance> distances)
        {
            string[] text = new string[distances.Count];

            for (int distIdx = 0; distIdx < distances.Count; distIdx++)
            {
                text[distIdx] += "Line " + distances[distIdx].startNodeV.startNode
                    + "-" + distances[distIdx].destNodeV.startNode + ": ";
                text[distIdx] += "status: " + distances[distIdx].isLineWorking.ToString() + ", ";

                text[distIdx] += distances[distIdx].lineCurrent.name + " = "
                    + PhasorMethods.PrintPhasor(distances[distIdx].lineCurrent.baseUnitValue) + ", ";
                text[distIdx] += distances[distIdx].startNodeV.name + " = "
                    + PhasorMethods.PrintPhasor(distances[distIdx].startNodeV.baseUnitValue) + ", ";
                text[distIdx] += distances[distIdx].destNodeV.name + " = "
                    + PhasorMethods.PrintPhasor(distances[distIdx].destNodeV.baseUnitValue) + ", ";

                for (int crntIdx = 0; crntIdx < distances[distIdx].otherCurrentsFromStartNode.Count;
                    crntIdx++)
                {
                    text[distIdx] += distances[distIdx].otherCurrentsFromStartNode[crntIdx].name + " = "
                        + PhasorMethods.PrintPhasor(
                            distances[distIdx].otherCurrentsFromStartNode[crntIdx].baseUnitValue);
                    if (crntIdx < distances[distIdx].otherCurrentsFromStartNode.Count - 1)
                        text[distIdx] += ", ";
                }

                for (int crntIdx = 0; crntIdx < distances[distIdx].otherCurrentsFromDestNode.Count;
                    crntIdx++)
                {
                    if (crntIdx == 0) text[distIdx] += ", ";
                    text[distIdx] += distances[distIdx].otherCurrentsFromDestNode[crntIdx].name + " = "
                        + PhasorMethods.PrintPhasor(
                            distances[distIdx].otherCurrentsFromDestNode[crntIdx].baseUnitValue) + ", ";
                }

                text[distIdx] += "Distance: " + Math.Round(distances[distIdx].distance, 4);
            }

            return text;
        }


        /// <summary>
        /// This method compares the test case to the training case to find the closest neighbors,
        ///     which are put into a list ordered by distance. The distance is a weighted euclidean
        ///     formula (square root of the sum of squares with the weights being multiples on the
        ///     squares). To improve performance, the entire list is not sorted, but instead each element
        ///     is compared to the largest distance on the list (if the distance list already has k
        ///     elements), replaces (if necessary) the largest distance and resorts the list if the
        ///     distance is smaller.
        /// </summary>
        /// <param name="trainingLines">
        /// The list of samples of the same line that the test case is compared to
        /// </param>
        /// <param name="testLine">
        /// The line the method is trying to find the nearest neighbors for to predict later
        /// </param>
        /// <param name="k">
        /// The number of nearest neighbors on the list
        /// </param>
        /// <returns>
        /// The list with the k nearest neighbors ordered by distance.
        /// </returns>
        public static List<Distance> GetKNN_List(List<Line> trainingLines,
            Line testLine, int k = 1)
        {
            List<Distance> distances = new List<Distance>();

            for (int trainLineIndex = 0; trainLineIndex < trainingLines.Count; trainLineIndex++)
            {
                double dist = GetEuclideanDistance(trainingLines[trainLineIndex], testLine);

                // Add to list when the list isn't full
                if (trainLineIndex < k)
                {
                    Distance distance = new Distance(trainingLines[trainLineIndex]);
                    distance.distance = dist;
                    distances.Add(distance);
                    distances = distances.OrderBy(x => x.distance).ToList();
                }

                /* Add to list and then reorder if the distance is less than the longest    *
                 *     that is currently on the list                                        */
                else if (dist < distances[k - 1].distance)
                {
                    Distance distance = new Distance(trainingLines[trainLineIndex]);
                    distance.distance = dist;
                    distances[k - 1] = distance;
                    distances = distances.OrderBy(x => x.distance).ToList();
                }
            }

            return distances;
        }

        /// <summary>
        /// This method calculates the weighted euclidean distance:
        ///     D = sqrt[Wline*abs(sLnCur - tLnCur)^2
        ///         + WnodeV*abs(sStartNodeV - tStartNodeV)^2 + WnodeV*abs(sDestNodeV - tDestNodeV)^2
        ///         + Woc/m * abs(sStartOtherCur[0] - tStartOtherCur[0])^2
        ///         + ... + Woc/m * abs(sStartOtherCur[m-1] - tStartOtherCur[m-1])^2
        ///         + Woc/n * abs(sDestOtherCur[0] - tDestOtherCur[0])^2
        ///         + ... + Woc/n * abs(sDestOtherCur[n-1] - tDestOtherCur[n-1])^2]
        ///     where m is the number of other start node currents and n is the number of other
        ///     destination node currents.
        /// </summary>
        /// <param name="sampleLine">
        /// A line from the training list
        /// </param>
        /// <param name="testLine">
        /// A line from the test list
        /// </param>
        /// <param name="Wline">
        /// The line current weight
        /// </param>
        /// <param name="WnodeV">
        /// The node voltage weight
        /// </param>
        /// <param name="Woc">
        /// The sum of the other currents squares weight
        /// </param>
        /// <returns>
        /// The euclidean distance from sampleLine to testLine
        /// </returns>
        public static double GetEuclideanDistance(Line sampleLine, Line testLine,
            double Wline = 10, double WnodeV = 5, double Woc = 1)
        {
            double distance = Wline * Math.Pow(
                (sampleLine.lineCurrent.baseUnitValue - testLine.lineCurrent.baseUnitValue).magnitude, 2);
            distance += WnodeV * Math.Pow(
                (sampleLine.startNodeV.baseUnitValue - testLine.startNodeV.baseUnitValue).magnitude, 2);
            distance += WnodeV * Math.Pow(
                (sampleLine.destNodeV.baseUnitValue - testLine.destNodeV.baseUnitValue).magnitude, 2);

            int numOfOtherStartCrnts = sampleLine.otherCurrentsFromStartNode.Count;
            if (numOfOtherStartCrnts > 0)
                for (int crntIdx = 0; crntIdx < numOfOtherStartCrnts; crntIdx++)
                    distance += Woc / numOfOtherStartCrnts * Math.Pow(
                        (sampleLine.otherCurrentsFromStartNode[crntIdx].baseUnitValue
                        - testLine.otherCurrentsFromStartNode[crntIdx].baseUnitValue).magnitude, 2);

            int numOfOtherDestCrnts = sampleLine.otherCurrentsFromDestNode.Count;
            if (numOfOtherDestCrnts > 0)
                for (int crntIdx = 0; crntIdx < numOfOtherDestCrnts; crntIdx++)
                    distance += Woc / numOfOtherDestCrnts * Math.Pow(
                        (sampleLine.otherCurrentsFromDestNode[crntIdx].baseUnitValue 
                        - testLine.otherCurrentsFromDestNode[crntIdx].baseUnitValue).magnitude, 2);

            return Math.Sqrt(distance);
        }


        /// <summary>
        /// This method predicts the line status based on the status of its nearest neighbors.
        /// </summary>
        /// <param name="knn">
        /// The line list of the nearest neighbors with their distances
        /// </param>
        /// <returns>
        /// The prediction for the test line's status
        /// </returns>
        public static bool PredictOutput(List<Distance> knn)
        {
            int trueOutputs = 0;
            int falseOutputs = 0;
            for (int lineIdx = 0; lineIdx < knn.Count; lineIdx++)
            {
                if (knn[lineIdx].isLineWorking) trueOutputs += 1;
                else falseOutputs += 1;
            }

            /* In the rare case where there are an equal number of true and false outputs,  *
             * predict the output as false.                                                 */
            if (trueOutputs > falseOutputs) return true;
            else return false;
        }


        /// <summary>
        /// This function creates a list of samples for each line with the test grid where by default
        ///     10 have all lines up and 5 have all lines up except line 1-2.
        /// </summary>
        /// <param name="numOfAllUpLines">
        /// The number of samples where all lines are up (default 10)
        /// </param>
        /// <param name="numOf12DownLines">
        /// The number of samples where every line except line 1-2 is up (default 5)
        /// </param>
        /// <returns>
        /// The list of samples for each line
        /// </returns>
        public static List<List<Line>> DemoTrainingList(int numOfAllUpLines = 10,
            int numOf12DownLines = 5)
        {
            List<List<Line>> trainingList = new List<List<Line>>();
            Random random = new Random();

            for (int allUpLineIdx = 0; allUpLineIdx < numOfAllUpLines; allUpLineIdx++)
                trainingList.Add(DemoLineListAllUp(random));
            for (int line12DownIdx = 0; line12DownIdx < numOf12DownLines; line12DownIdx++)
                trainingList.Add(DemoLine12Down(random));

            return trainingList;
        }

        /// <summary>
        /// This method creates a test sample for each of the lines where by default, there is a 50%
        ///     chance line 1-2 is down, but all other lines will always be up.
        /// </summary>
        /// <param name="line12DownChance">
        /// The probability the output will have line 1-2 down (default 0.5)
        /// </param>
        /// <returns>
        /// The list with the test case for each line
        /// </returns>
        public static List<Line> DemoTestList(double line12DownChance = 0.5)
        {
            Random random = new Random();
            if (random.NextDouble() < line12DownChance) return DemoLine12Down(random);
            else return DemoLineListAllUp(random);
        }

        /// <summary>
        /// This method creates a list with a sample for each line where all lines are up.
        /// </summary>
        /// <param name="random">
        /// This is the instance of the Random class used to randomly generate the training and
        ///     test lists.
        /// </param>
        /// <returns>
        /// A list with a sample for each line where all lines are up
        /// </returns>
        private static List<Line> DemoLineListAllUp(Random random)
        {
            bool[,] connections = new bool[3, 4] {
                { true, false, true, true },
                { true, true, false, false },
                { true, true, false, false } };

            double[] meanVoltageMagnitudes = { 1, 0.9, 0.9 };
            double[] minVoltageMagnitudes = new double[3];
            double[] maxVoltageMagnitudes = new double[3];
            for (int row = 0; row < minVoltageMagnitudes.Length; row++)
            {
                minVoltageMagnitudes[row] = 0.9 * meanVoltageMagnitudes[row];
                maxVoltageMagnitudes[row] = 1.1 * meanVoltageMagnitudes[row];
            }
            double[] minVoltagePhaseAngles = { -10, -10, -10 };
            double[] maxVoltagePhaseAngles = { 10, 10, 10 };

            double[,] meanCurrentMagnitudes = new double[3, 4] {
                { 1, 0, 0.5, 0.5 },
                { 0.5, 0.5, 0, 0 },
                { 0.5, 0.5, 0, 0 } };
            double[,] minCurrentMagnitudes = new double[3, 4];
            double[,] maxCurrentMagnitudes = new double[3, 4];
            for (int row = 0; row < 3; row++)
                for (int clm = 0; clm < 4; clm++)
                {
                    minCurrentMagnitudes[row, clm] = 0.9 * meanCurrentMagnitudes[row, clm];
                    maxCurrentMagnitudes[row, clm] = 1.1 * meanCurrentMagnitudes[row, clm];
                }
            double[,] minCurrentPhaseAngles = new double[3, 4] {
                { 170, 0, -10, -10 },
                { -10, 170, 0, 0 },
                { -10, 170, 0, 0 } };
            double[,] maxCurrentPhaseAngles = new double[3, 4] {
                { 190, 0, 10, 10 },
                { 10, 190, 0, 0 },
                { 10, 190, 0, 0 } };

            // Get Random Voltages and Currents
            PolarPhasor[] voltages = new PolarPhasor[3];
            for (int row = 0; row < voltages.Length; row++)
            {
                voltages[row] = RandomWithinMargin(minVoltageMagnitudes[row], maxVoltageMagnitudes[row],
                    minVoltagePhaseAngles[row], maxVoltagePhaseAngles[row], random);
                if (voltages[row].phaseAngleDegrees > 180) voltages[row].phaseAngleDegrees -= 360;
            }
            PolarPhasor[,] currents = new PolarPhasor[3, 4];
            for (int row = 0; row < 3; row++)
                for (int clm = 0; clm < 4; clm++)
                {
                    currents[row, clm] = RandomWithinMargin(minCurrentMagnitudes[row, clm],
                        maxCurrentMagnitudes[row, clm],
                        minCurrentPhaseAngles[row, clm], maxCurrentPhaseAngles[row, clm], random);
                    if (currents[row, clm].phaseAngleDegrees > 180)
                        currents[row, clm].phaseAngleDegrees -= 360;
                }

            List<Node> nodes = NodeList(connections, voltages, currents);
            List<Line> lines = LineList(connections, nodes);
            return lines;
        }

        /// <summary>
        /// This method creates a list with a sample for each line where all lines except line 1-2
        ///     are up.
        /// </summary>
        /// <param name="random">
        /// This is the instance of the Random class used to randomly generate the training and
        ///     test lists.
        /// </param>
        /// <returns>
        /// A list with a sample for each line where all lines except line 1-2 are up
        /// </returns>
        private static List<Line> DemoLine12Down(Random random)
        {
            // The currents and voltages will each be between 90% and 110% of these values.
            bool[,] connections = new bool[3, 4] {
                { true, false, true, true },
                { true, true, false, false },
                { true, true, false, false } };

            double[] meanVoltageMagnitudes = { 1, 0, 0.9 };
            double[] minVoltageMagnitudes = new double[3];
            double[] maxVoltageMagnitudes = new double[3];
            for (int row = 0; row < minVoltageMagnitudes.Length; row++)
            {
                minVoltageMagnitudes[row] = 0.9 * meanVoltageMagnitudes[row];
                maxVoltageMagnitudes[row] = 1.1 * meanVoltageMagnitudes[row];
            }
            double[] minVoltagePhaseAngles = { -10, 0, -10 };
            double[] maxVoltagePhaseAngles = { 10, 0, 10 };

            double[,] meanCurrentMagnitudes = new double[3, 4] {
                { -1, 0, 0, 1 },
                { 0, 0, 0, 0 },
                { 1, -1, 0, 0 } };
            double[,] minCurrentMagnitudes = new double[3, 4];
            double[,] maxCurrentMagnitudes = new double[3, 4];
            for (int row = 0; row < 3; row++)
                for (int clm = 0; clm < 4; clm++)
                {
                    minCurrentMagnitudes[row, clm] = 0.9 * meanCurrentMagnitudes[row, clm];
                    maxCurrentMagnitudes[row, clm] = 1.1 * meanCurrentMagnitudes[row, clm];
                }
            double[,] minCurrentPhaseAngles = new double[3, 4] {
                { 170, 0, 0, -10 },
                { 0, 0, 0, 0 },
                { -10, 170, 0, 0 } };
            double[,] maxCurrentPhaseAngles = new double[3, 4] {
                { 190, 0, 0, 10 },
                { 0, 0, 0, 0 },
                { 10, 190, 0, 0 } };

            // Get Random Voltages and Currents
            PolarPhasor[] voltages = new PolarPhasor[3];
            for (int row = 0; row < voltages.Length; row++)
            {
                voltages[row] = RandomWithinMargin(minVoltageMagnitudes[row], maxVoltageMagnitudes[row],
                    minVoltagePhaseAngles[row], maxVoltagePhaseAngles[row], random);
                if (voltages[row].phaseAngleDegrees > 180) voltages[row].phaseAngleDegrees -= 360;
            }
            PolarPhasor[,] currents = new PolarPhasor[3, 4];
            for (int row = 0; row < 3; row++)
                for (int clm = 0; clm < 4; clm++)
                {
                    currents[row, clm] = RandomWithinMargin(minCurrentMagnitudes[row, clm],
                        maxCurrentMagnitudes[row, clm],
                        minCurrentPhaseAngles[row, clm], maxCurrentPhaseAngles[row, clm], random);
                    if (currents[row, clm].phaseAngleDegrees > 180)
                        currents[row, clm].phaseAngleDegrees -= 360;
                }

            List<Node> nodes = NodeList(connections, voltages, currents);

            /* Statuses refer to if the line is working, while connections state whether    *
             *     or not a line exists.                                                    */
            bool[,] statuses = new bool[3, 4] {
                { true, false, false, true },
                { true, false, false, false },
                { true, true, false, false } };
            
            List<Line> lines = LineList(statuses, nodes);
            return lines;
        }

        /// <summary>
        /// This method returns a random polar phasor with magnitudes and phase angles between the
        /// specified parameters.
        /// </summary>
        /// <param name="minMagnitude">
        /// The minimum magnitude possible
        /// </param>
        /// <param name="maxMagnitude">
        /// The maximum magnitude possible
        /// </param>
        /// <param name="minPhaseAngleDegrees">
        /// The minimum phase angle possible
        /// </param>
        /// <param name="maxPhaseAngleDegrees">
        /// The maximum phase angle possible
        /// </param>
        /// <param name="random">
        /// The instance of the class Random used to create the training and test lists
        /// </param>
        /// <returns>
        /// A phasor in polar form with magnitudes and phase angles between the specified parameters
        /// </returns>
        private static PolarPhasor RandomWithinMargin(double minMagnitude, double maxMagnitude,
            double minPhaseAngleDegrees, double maxPhaseAngleDegrees, Random random)
        {
            double magnitude = minMagnitude + (maxMagnitude - minMagnitude) * random.NextDouble();
            double phaseAngleDegrees = minPhaseAngleDegrees +
                (maxPhaseAngleDegrees - minPhaseAngleDegrees) * random.NextDouble();
            return new PolarPhasor(magnitude, phaseAngleDegrees);
        }
    }

}
