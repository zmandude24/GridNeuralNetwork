﻿namespace GridNeuralNetwork
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox = new System.Windows.Forms.TextBox();
            this.buttonPrintTrainList = new System.Windows.Forms.Button();
            this.buttonTestLine12Demo = new System.Windows.Forms.Button();
            this.buttonPrintTestList = new System.Windows.Forms.Button();
            this.buttonNewTestData = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(13, 13);
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.ReadOnly = true;
            this.textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox.Size = new System.Drawing.Size(945, 381);
            this.textBox.TabIndex = 0;
            // 
            // buttonPrintTrainList
            // 
            this.buttonPrintTrainList.Location = new System.Drawing.Point(13, 415);
            this.buttonPrintTrainList.Name = "buttonPrintTrainList";
            this.buttonPrintTrainList.Size = new System.Drawing.Size(156, 23);
            this.buttonPrintTrainList.TabIndex = 1;
            this.buttonPrintTrainList.Text = "Print Training List";
            this.buttonPrintTrainList.UseVisualStyleBackColor = true;
            this.buttonPrintTrainList.Click += new System.EventHandler(this.buttonPrintTrainList_Click);
            // 
            // buttonTestLine12Demo
            // 
            this.buttonTestLine12Demo.Location = new System.Drawing.Point(296, 415);
            this.buttonTestLine12Demo.Name = "buttonTestLine12Demo";
            this.buttonTestLine12Demo.Size = new System.Drawing.Size(165, 23);
            this.buttonTestLine12Demo.TabIndex = 2;
            this.buttonTestLine12Demo.Text = "Test Line 12 Demo";
            this.buttonTestLine12Demo.UseVisualStyleBackColor = true;
            this.buttonTestLine12Demo.Click += new System.EventHandler(this.buttonTestLine12Demo_Click);
            // 
            // buttonPrintTestList
            // 
            this.buttonPrintTestList.Location = new System.Drawing.Point(176, 415);
            this.buttonPrintTestList.Name = "buttonPrintTestList";
            this.buttonPrintTestList.Size = new System.Drawing.Size(114, 23);
            this.buttonPrintTestList.TabIndex = 3;
            this.buttonPrintTestList.Text = "Print Test List";
            this.buttonPrintTestList.UseVisualStyleBackColor = true;
            this.buttonPrintTestList.Click += new System.EventHandler(this.buttonPrintTestList_Click);
            // 
            // buttonNewTestData
            // 
            this.buttonNewTestData.Location = new System.Drawing.Point(468, 415);
            this.buttonNewTestData.Name = "buttonNewTestData";
            this.buttonNewTestData.Size = new System.Drawing.Size(128, 23);
            this.buttonNewTestData.TabIndex = 4;
            this.buttonNewTestData.Text = "New Test Data";
            this.buttonNewTestData.UseVisualStyleBackColor = true;
            this.buttonNewTestData.Click += new System.EventHandler(this.buttonNewTestData_Click);
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 450);
            this.Controls.Add(this.buttonNewTestData);
            this.Controls.Add(this.buttonPrintTestList);
            this.Controls.Add(this.buttonTestLine12Demo);
            this.Controls.Add(this.buttonPrintTrainList);
            this.Controls.Add(this.textBox);
            this.Name = "Form";
            this.Text = "Grid Neural Network";
            this.Load += new System.EventHandler(this.Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button buttonPrintTrainList;
        private System.Windows.Forms.Button buttonTestLine12Demo;
        private System.Windows.Forms.Button buttonPrintTestList;
        private System.Windows.Forms.Button buttonNewTestData;
    }
}

