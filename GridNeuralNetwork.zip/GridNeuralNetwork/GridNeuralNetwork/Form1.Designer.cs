﻿namespace GridNeuralNetwork
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox = new System.Windows.Forms.TextBox();
            this.buttonNewTestData = new System.Windows.Forms.Button();
            this.buttonPrintTestList = new System.Windows.Forms.Button();
            this.buttonPrintTrainingList = new System.Windows.Forms.Button();
            this.buttonTestLine12Demo = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(13, 13);
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.ReadOnly = true;
            this.textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox.Size = new System.Drawing.Size(945, 396);
            this.textBox.TabIndex = 0;
            this.textBox.WordWrap = false;
            // 
            // buttonNewTestData
            // 
            this.buttonNewTestData.Location = new System.Drawing.Point(785, 415);
            this.buttonNewTestData.Name = "buttonNewTestData";
            this.buttonNewTestData.Size = new System.Drawing.Size(173, 23);
            this.buttonNewTestData.TabIndex = 5;
            this.buttonNewTestData.Text = "New Test Data";
            this.buttonNewTestData.UseVisualStyleBackColor = true;
            this.buttonNewTestData.Click += new System.EventHandler(this.buttonNewTestData_Click);
            // 
            // buttonPrintTestList
            // 
            this.buttonPrintTestList.Location = new System.Drawing.Point(265, 415);
            this.buttonPrintTestList.Name = "buttonPrintTestList";
            this.buttonPrintTestList.Size = new System.Drawing.Size(154, 23);
            this.buttonPrintTestList.TabIndex = 6;
            this.buttonPrintTestList.Text = "Print Test List";
            this.buttonPrintTestList.UseVisualStyleBackColor = true;
            this.buttonPrintTestList.Click += new System.EventHandler(this.buttonPrintTestList_Click);
            // 
            // buttonPrintTrainingList
            // 
            this.buttonPrintTrainingList.Location = new System.Drawing.Point(12, 415);
            this.buttonPrintTrainingList.Name = "buttonPrintTrainingList";
            this.buttonPrintTrainingList.Size = new System.Drawing.Size(185, 23);
            this.buttonPrintTrainingList.TabIndex = 7;
            this.buttonPrintTrainingList.Text = "Print Training List";
            this.buttonPrintTrainingList.UseVisualStyleBackColor = true;
            this.buttonPrintTrainingList.Click += new System.EventHandler(this.buttonPrintTrainingList_Click);
            // 
            // buttonTestLine12Demo
            // 
            this.buttonTestLine12Demo.Location = new System.Drawing.Point(513, 415);
            this.buttonTestLine12Demo.Name = "buttonTestLine12Demo";
            this.buttonTestLine12Demo.Size = new System.Drawing.Size(191, 23);
            this.buttonTestLine12Demo.TabIndex = 8;
            this.buttonTestLine12Demo.Text = "Test Line 12 Demo";
            this.buttonTestLine12Demo.UseVisualStyleBackColor = true;
            this.buttonTestLine12Demo.Click += new System.EventHandler(this.buttonTestLine12Demo_Click);
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 450);
            this.Controls.Add(this.buttonTestLine12Demo);
            this.Controls.Add(this.buttonPrintTrainingList);
            this.Controls.Add(this.buttonPrintTestList);
            this.Controls.Add(this.buttonNewTestData);
            this.Controls.Add(this.textBox);
            this.Name = "Form";
            this.Text = "Grid Neural Network";
            this.Load += new System.EventHandler(this.Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button buttonNewTestData;
        private System.Windows.Forms.Button buttonPrintTestList;
        private System.Windows.Forms.Button buttonPrintTrainingList;
        private System.Windows.Forms.Button buttonTestLine12Demo;
    }
}

