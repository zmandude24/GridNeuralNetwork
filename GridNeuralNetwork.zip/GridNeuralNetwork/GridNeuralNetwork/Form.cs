﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GridNeuralNetwork
{
    public partial class Form : System.Windows.Forms.Form
    {
        private List<LineList> trainingList;

        public Form()
        {
            InitializeComponent();
        }

        private void Form_Load(object sender, EventArgs e)
        {
            trainingList = NodeMethods.GridA_LineListsFromFile();
        }

        private void buttonCreateLineLists_Click(object sender, EventArgs e)
        {
            trainingList = NodeMethods.GridA_LineListsFromFile();
        }

        private void buttonPrintLineLists_Click(object sender, EventArgs e)
        {
            string[] text = NodeMethods.PrintLineList(trainingList[0]);
            textBox.Clear();
            for (int i = 0; i < text.Length; i++)
            {
                if (i == text.Length - 1)
                    textBox.Text = textBox.Text + text[i];
                else
                    textBox.Text = textBox.Text + text[i] + "\r\n";
            }
        }
    }

    public class Measurement
    {
        public double value;    // in p.u.
        public uint node;       // receiving node
    }

    public class Node
    {
        public uint number;             // the nominal value
        public Measurement V;           // node voltage
        public Measurement I0;          // current from node directly to ground
        public List<Measurement> Ik;    // currents to adjacent nodes
    }
    public class NodeList
    {
        public List<Node> nodes;

        // connections: n x n+1 matrix with true or false for direct connections
        // voltages: n matrix with the voltages
        // currents: n x n+1 matrix with the currents
        public NodeList(bool[,] connections, double[] voltages, double[,] currents)
        {
            nodes = new List<Node>();

            for (uint row = 1; row <= connections.GetLength(0); row++)
            {
                Node newNode = new Node();

                newNode.number = row;

                newNode.V = new Measurement();
                newNode.V.value = voltages[row - 1];
                newNode.V.node = row;

                newNode.I0 = new Measurement();
                newNode.I0.node = 0;
                if (connections[row - 1, 0]) newNode.I0.value = currents[row - 1, 0];
                else newNode.I0.value = 0;

                newNode.Ik = new List<Measurement>();
                for (uint clm = 1; clm < connections.GetLength(1); clm++)
                {
                    if (connections[row - 1, clm])
                    {
                        Measurement Ik = new Measurement();
                        Ik.node = clm;
                        Ik.value = currents[row - 1, clm];
                        newNode.Ik.Add(Ik);
                    }
                }

                nodes.Add(newNode);
            }
        }
    }

    public class Line
    {
        public Measurement Va;          // node a voltage
        public Measurement Vb;          // node b voltage
        public Measurement Iatob;       // current directly from node a to node b
        public List<Measurement> Ia;    // currents directly from node a (excluding Iatob)
        public List<Measurement> Ib;    // currents directly from node b (excluding -Iatob)
        public bool status;             // is the line working as intended?
    }
    public class LineList
    {
        public List<Line> lines;

        // statuses: n x n matrix with line statuses for line row -> clm
        public LineList(bool[,] statuses, NodeList nodeList)
        {
            int n = nodeList.nodes.Count;

            lines = new List<Line>();
            for (int row = 1; row <= n - 1; row++)
            {
                for (int clm = row + 1; clm <= n; clm++)
                {
                    bool isConnected = false;
                    for (int i = 0; i < nodeList.nodes[row - 1].Ik.Count; i++)
                    {
                        if (nodeList.nodes[row - 1].Ik[i].node == (uint)clm)
                        {
                            isConnected = true;
                            break;
                        }
                    }

                    if (isConnected)
                    {
                        Line newLine = new Line();

                        newLine.Va = nodeList.nodes[row - 1].V;
                        newLine.Vb = nodeList.nodes[clm - 1].V;

                        newLine.Iatob = new Measurement();
                        for (int i = 0; i < nodeList.nodes[row - 1].Ik.Count; i++)
                        {
                            if (nodeList.nodes[row - 1].Ik[i].node == newLine.Vb.node)
                            {
                                newLine.Iatob = nodeList.nodes[row - 1].Ik[i];
                                break;
                            }
                        }

                        newLine.Ia = new List<Measurement>();
                        for (int i = 0; i < nodeList.nodes[row - 1].Ik.Count; i++)
                        {
                            if (nodeList.nodes[row - 1].Ik[i].node != newLine.Vb.node)
                                newLine.Ia.Add(nodeList.nodes[row - 1].Ik[i]);
                        }

                        newLine.Ib = new List<Measurement>();
                        for (int i = 0; i < nodeList.nodes[clm - 1].Ik.Count; i++)
                        {
                            if (nodeList.nodes[clm - 1].Ik[i].node != newLine.Va.node)
                                newLine.Ib.Add(nodeList.nodes[clm - 1].Ik[i]);
                        }

                        newLine.status = statuses[row - 1, clm - 1];

                        lines.Add(newLine);
                    }
                }
            }
        }
    }

    public static class NodeMethods
    {
        public static List<LineList> GridA_LineListsFromFile()
        {
            List<LineList> lineLists = new List<LineList>();

            int n = -1;  // number of measurements for each parameter
            foreach (string line in System.IO.File.ReadAllLines(
                @"C:\Users\zmand\OneDrive\Documents\Measurements.txt"))
                n = n + 1;

            string[] text = new string[n + 1];
            int lineNum = 0;
            foreach (string line in System.IO.File.ReadAllLines(
                @"C:\Users\zmand\OneDrive\Documents\Measurements.txt"))
            {
                text[lineNum] = line;
                lineNum = lineNum + 1;
            }

            foreach (string line in text)
            {
                Console.WriteLine(line);
            }

            // File Format:
            // V1 I13up I13 V2 I24up I24 V3 I34up I34 I35up I35 V4 I40up I40 I46up I46 ...
            //     V5 I50up I50 I56up I56 V6 I60up I60
            for (int i = 1; i < text.Length; i++)
            {
                char[] charSeparator = { ' ' };
                string[] measurements = text[i].Split(charSeparator,
                    StringSplitOptions.RemoveEmptyEntries);

                double V1 = double.Parse(measurements[0]);
                bool I13up = bool.Parse(measurements[1]);
                double I13 = double.Parse(measurements[2]);

                double V2 = double.Parse(measurements[3]);
                bool I24up = bool.Parse(measurements[4]);
                double I24 = double.Parse(measurements[5]);

                double V3 = double.Parse(measurements[6]);
                bool I34up = bool.Parse(measurements[7]);
                double I34 = double.Parse(measurements[8]);
                bool I35up = bool.Parse(measurements[9]);
                double I35 = double.Parse(measurements[10]);

                double V4 = double.Parse(measurements[11]);
                bool I40up = bool.Parse(measurements[12]);
                double I40 = double.Parse(measurements[13]);
                bool I46up = bool.Parse(measurements[14]);
                double I46 = double.Parse(measurements[15]);

                double V5 = double.Parse(measurements[16]);
                bool I50up = bool.Parse(measurements[17]);
                double I50 = double.Parse(measurements[18]);
                bool I56up = bool.Parse(measurements[19]);
                double I56 = double.Parse(measurements[20]);

                double V6 = double.Parse(measurements[21]);
                bool I60up = bool.Parse(measurements[22]);
                double I60 = double.Parse(measurements[23]);

                // connections: n x n+1 matrix with true or false for direct connections
                // voltages: n matrix with the voltages
                // currents: n x n+1 matrix with the currents
                bool[,] connections = {
                    { true, false, false, true, false, false, false },
                    { true, false, false, false, true, false, false },
                    { false, true, false, false, true, true, false },
                    { true, false, true, true, false, false, true },
                    { true, false, false, true, false, false, true },
                    { true, false, false, false, true, true, false } };
                double[] voltages = { V1, V2, V3, V4, V5, V6 };
                double[,] currents = {
                    { -I13, 0, 0, I13, 0, 0, 0 },
                    { -I24, 0, 0, 0, I24, 0, 0 },
                    { 0, -I13, 0, 0, I34, I35, 0 },
                    { I40, 0, -I24, -I34, 0, 0, I46 },
                    { I50, 0, 0, -I35, 0, 0, I56 },
                    { I60, 0, 0, 0, -I46, -I56, 0} };
                NodeList nodeList = new NodeList(connections, voltages, currents);

                bool[,] statuses = {
                    { false, false, I13up, false, false, false },
                    { false, false, false, I24up, false, false },
                    { I13up, false, false, I34up, I35up, false },
                    { false, I24up, I34up, false, false, I46up },
                    { false, false, I35up, false, false, I56up },
                    { false, false, false, I46up, I56up, false } };
                LineList lineList = new LineList(statuses, nodeList);

                lineLists.Add(lineList);
            }

            return lineLists;
        }

        public static string[] PrintNodeList(NodeList nodeList)
        {
            uint lines = 0;
            for (int i = 0; i < nodeList.nodes.Count; i++)
                lines = lines + 3 + (uint)nodeList.nodes[i].Ik.Count;
            string[] text = new string[lines];

            int line = 0;
            for (int i = 0; i < nodeList.nodes.Count; i++)
            {
                string[] nodeText = PrintNode(nodeList.nodes[i]);
                for (int j = 0; j < nodeText.Length; j++)
                {
                    text[line] = nodeText[j];
                    line = line + 1;
                }
            }

            return text;
        }
        public static string[] PrintNode(Node node)
        {
            uint lines = 3 + (uint)node.Ik.Count;
            string[] text = new string[lines];

            text[0] = "Node: " + node.number;
            text[1] = "V" + node.number + " = " + node.V.value;
            text[2] = "I0 = " + node.I0.value;
            for (int i = 3; i < lines; i++)
                text[i] = "I" + node.Ik[i - 3].node + " = " + node.Ik[i - 3].value;

            return text;
        }

        public static string[] PrintLineList(LineList lineList)
        {
            uint lines = 0;
            for (int i = 0; i < lineList.lines.Count; i++)
                lines = lines + 5 +
                    (uint)(lineList.lines[i].Ia.Count + lineList.lines[i].Ib.Count);
            string[] text = new string[lines];

            int line = 0;
            for (int i = 0; i < lineList.lines.Count; i++)
            {
                string[] lineText = PrintLine(lineList.lines[i]);
                for (int j = 0; j < lineText.Length; j++)
                {
                    text[line] = lineText[j];
                    line = line + 1;
                }
            }

            return text;
        }
        public static string[] PrintLine(Line line)
        {
            uint lines = 5 + (uint)(line.Ia.Count + line.Ib.Count);
            string[] text = new string[lines];

            text[0] = "Line " + line.Va.node + " to " + line.Vb.node;
            text[1] = "V" + line.Va.node + " = " + line.Va.value;
            text[2] = "V" + line.Vb.node + " = " + line.Vb.value;
            text[3] = "I" + line.Va.node + "to" + line.Vb.node + " = " + line.Iatob.value;
            for (int i = 0; i < line.Ia.Count; i++)
                text[i + 4] = "I" + line.Ia[i].node + " = " + line.Ia[i].value;
            for (int i = 0; i < line.Ib.Count; i++)
                text[i + line.Ia.Count + 4] =
                    "I" + line.Ib[i].node + " = " + line.Ib[i].value;
            text[text.Length - 1] = line.status.ToString();

            return text;
        }
    }
}