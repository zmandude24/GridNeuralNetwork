﻿namespace GridNeuralNetwork
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox = new System.Windows.Forms.TextBox();
            this.buttonCreateLineLists = new System.Windows.Forms.Button();
            this.buttonPrintLineLists = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(13, 13);
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox.Size = new System.Drawing.Size(775, 377);
            this.textBox.TabIndex = 0;
            // 
            // buttonCreateLineLists
            // 
            this.buttonCreateLineLists.Location = new System.Drawing.Point(13, 415);
            this.buttonCreateLineLists.Name = "buttonCreateLineLists";
            this.buttonCreateLineLists.Size = new System.Drawing.Size(124, 23);
            this.buttonCreateLineLists.TabIndex = 1;
            this.buttonCreateLineLists.Text = "Create Line Lists";
            this.buttonCreateLineLists.UseVisualStyleBackColor = true;
            this.buttonCreateLineLists.Click += new System.EventHandler(this.buttonCreateLineLists_Click);
            // 
            // buttonPrintLineLists
            // 
            this.buttonPrintLineLists.Location = new System.Drawing.Point(144, 415);
            this.buttonPrintLineLists.Name = "buttonPrintLineLists";
            this.buttonPrintLineLists.Size = new System.Drawing.Size(108, 23);
            this.buttonPrintLineLists.TabIndex = 2;
            this.buttonPrintLineLists.Text = "Print Line Lists";
            this.buttonPrintLineLists.UseVisualStyleBackColor = true;
            this.buttonPrintLineLists.Click += new System.EventHandler(this.buttonPrintLineLists_Click);
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonPrintLineLists);
            this.Controls.Add(this.buttonCreateLineLists);
            this.Controls.Add(this.textBox);
            this.Name = "Form";
            this.Text = "Power Grid Neural Network";
            this.Load += new System.EventHandler(this.Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button buttonCreateLineLists;
        private System.Windows.Forms.Button buttonPrintLineLists;
    }
}

