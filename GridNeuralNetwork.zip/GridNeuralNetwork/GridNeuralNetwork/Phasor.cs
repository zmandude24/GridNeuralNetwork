﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GridNeuralNetwork
{
    /// <summary>
    /// This class is a phasor or imaginary number in cartesian form (a.k.a. a + j*b).
    /// </summary>
    public class CartesianPhasor
    {
        public double real { get; set; }
        public double imag { get; set; }

        public CartesianPhasor(double real, double imag)
        {
            this.real = real;
            this.imag = imag;
        }

        private static CartesianPhasor ToCartesian(PolarPhasor polarPhasor)
        {
            double real = polarPhasor.magnitude * Math.Cos(Math.PI / 180 * polarPhasor.phaseAngleDegrees);
            double imag = polarPhasor.magnitude * Math.Sin(Math.PI / 180 * polarPhasor.phaseAngleDegrees);

            CartesianPhasor cartesianPhasor = new CartesianPhasor(real, imag);
            return cartesianPhasor;
        }
        private static PolarPhasor ToPolar(CartesianPhasor cartesianPhasor)
        {
            double magnitude = Math.Sqrt(Math.Pow(cartesianPhasor.real, 2)
                + Math.Pow(cartesianPhasor.imag, 2));

            double phaseAngleDegrees = 0;
            if (magnitude > 0)
            {
                // The phasor is on the y-axis line.
                if (cartesianPhasor.real == 0)
                {
                    if (cartesianPhasor.imag > 0) phaseAngleDegrees = 90;
                    else phaseAngleDegrees = -90;
                }

                // The phasor is on the left side of the unit circle chart.
                else if (cartesianPhasor.real < 0)
                {
                    // The phasor is in the second quadrant.
                    if (cartesianPhasor.imag >= 0)
                        phaseAngleDegrees = 180 + 180 / Math.PI
                             * Math.Atan(cartesianPhasor.imag / cartesianPhasor.real);

                    // The phasor is in the third quadrant.
                    else
                        phaseAngleDegrees = -180 + 180 / Math.PI
                            * Math.Atan(cartesianPhasor.imag / cartesianPhasor.real);
                }

                // The phasor is on the right side of the unit circle chart.
                else
                {
                    phaseAngleDegrees = 180 / Math.PI
                        * Math.Atan(cartesianPhasor.imag / cartesianPhasor.real);
                }
            }

            PolarPhasor polarPhasor = new PolarPhasor(magnitude, phaseAngleDegrees);
            return polarPhasor;
        }

        public static CartesianPhasor operator+ (CartesianPhasor a, CartesianPhasor b)
        {
            double real = a.real + b.real;
            double imag = a.imag + b.imag;
            return new CartesianPhasor(real, imag);
        }
        public static CartesianPhasor operator- (CartesianPhasor a, CartesianPhasor b)
        {
            double real = a.real - b.real;
            double imag = a.imag - b.imag;
            return new CartesianPhasor(real, imag);
        }
        public static CartesianPhasor operator* (CartesianPhasor a, CartesianPhasor b)
        {
            PolarPhasor polarA = ToPolar(a);
            PolarPhasor polarB = ToPolar(b);
            return ToCartesian(polarA * polarB);
        }
        public static CartesianPhasor operator/ (CartesianPhasor a, CartesianPhasor b)
        {
            PolarPhasor polarA = ToPolar(a);
            PolarPhasor polarB = ToPolar(b);
            return ToCartesian(polarA / polarB);
        }
    }


    /// <summary>
    /// This class is a phasor or imaginary number in polar form (a.k.a r /_ theta).
    /// </summary>
    public class PolarPhasor
    {
        public double magnitude { get; set; }
        public double phaseAngleDegrees { get; set; }

        public PolarPhasor(double magnitude, double phaseAngleDegrees)
        {
            this.magnitude = magnitude;
            this.phaseAngleDegrees = phaseAngleDegrees;
        }

        private static CartesianPhasor ToCartesian(PolarPhasor polarPhasor)
        {
            double real = polarPhasor.magnitude * Math.Cos(Math.PI / 180 * polarPhasor.phaseAngleDegrees);
            double imag = polarPhasor.magnitude * Math.Sin(Math.PI / 180 * polarPhasor.phaseAngleDegrees);

            CartesianPhasor cartesianPhasor = new CartesianPhasor(real, imag);
            return cartesianPhasor;
        }
        private static PolarPhasor ToPolar(CartesianPhasor cartesianPhasor)
        {
            double magnitude = Math.Sqrt(Math.Pow(cartesianPhasor.real, 2)
                + Math.Pow(cartesianPhasor.imag, 2));

            double phaseAngleDegrees = 0;
            if (magnitude > 0)
            {
                // The phasor is on the y-axis line.
                if (cartesianPhasor.real == 0)
                {
                    if (cartesianPhasor.imag > 0) phaseAngleDegrees = 90;
                    else phaseAngleDegrees = -90;
                }

                // The phasor is on the left side of the unit circle chart.
                else if (cartesianPhasor.real < 0)
                {
                    // The phasor is in the second quadrant.
                    if (cartesianPhasor.imag >= 0)
                        phaseAngleDegrees = 180 + 180 / Math.PI
                             * Math.Atan(cartesianPhasor.imag / cartesianPhasor.real);

                    // The phasor is in the third quadrant.
                    else
                        phaseAngleDegrees = -180 + 180 / Math.PI
                            * Math.Atan(cartesianPhasor.imag / cartesianPhasor.real);
                }

                // The phasor is on the right side of the unit circle chart.
                else
                {
                    phaseAngleDegrees = 180 / Math.PI
                        * Math.Atan(cartesianPhasor.imag / cartesianPhasor.real);
                }
            }

            PolarPhasor polarPhasor = new PolarPhasor(magnitude, phaseAngleDegrees);
            return polarPhasor;
        }

        public static PolarPhasor operator+ (PolarPhasor a, PolarPhasor b)
        {
            CartesianPhasor cartesianA = ToCartesian(a);
            CartesianPhasor cartesianB = ToCartesian(b);
            return ToPolar(cartesianA + cartesianB);
        }
        public static PolarPhasor operator- (PolarPhasor a, PolarPhasor b)
        {
            CartesianPhasor cartesianA = ToCartesian(a);
            CartesianPhasor cartesianB = ToCartesian(b);
            return ToPolar(cartesianA - cartesianB);
        }
        public static PolarPhasor operator* (PolarPhasor a, PolarPhasor b)
        {
            double magnitude = a.magnitude * b.magnitude;
            double phaseAngleDegrees = a.phaseAngleDegrees + b.phaseAngleDegrees;
            while (phaseAngleDegrees > 180) phaseAngleDegrees -= 360;
            while (phaseAngleDegrees <= -180) phaseAngleDegrees += 360;
            return new PolarPhasor(magnitude, phaseAngleDegrees);
        }
        public static PolarPhasor operator/ (PolarPhasor a, PolarPhasor b)
        {
            double magnitude = a.magnitude / b.magnitude;
            double phaseAngleDegrees = a.phaseAngleDegrees - b.phaseAngleDegrees;
            while (phaseAngleDegrees > 180) phaseAngleDegrees -= 360;
            while (phaseAngleDegrees <= -180) phaseAngleDegrees += 360;
            return new PolarPhasor(magnitude, phaseAngleDegrees);
        }
    }

    public static class PhasorMethods
    {
        /// <summary>
        /// This method returns a string of the printed cartesian form input phasor rounded to the
        /// nearest four decimal places.
        /// </summary>
        /// <param name="phasor">
        /// The phasor to print
        /// </param>
        /// <returns>
        /// The string form of the printed phasor
        /// </returns>
        public static string PrintPhasor(CartesianPhasor phasor)
        {
            string text;

            if (phasor.imag < 0)
                text = Math.Round(phasor.real, 4) + " - j" + Math.Round(-phasor.imag, 4);
            
            else text = Math.Round(phasor.real, 4) + " + j" + Math.Round(phasor.imag, 4);
            
            return text;
        }
        /// <summary>
        /// This method returns a string of the printed polar form input phasor with the magnitude
        /// rounded to the nearest four decimal places and the phase angle rounded to the nearest
        /// two decimal places.
        /// </summary>
        /// <param name="phasor">
        /// The phasor to print
        /// </param>
        /// <returns>
        /// The string form of the printed phasor
        /// </returns>
        public static string PrintPhasor(PolarPhasor phasor)
        {
            return Math.Round(phasor.magnitude, 4) + " @" + Math.Round(phasor.phaseAngleDegrees, 2)
                + "deg";
        }


        /// <summary>
        /// This method converts a cartesian phasor to a polar phasor by finding the magnitude and
        /// the phase angle in degrees. The magnitude is sqrt(real^2 + imag^2) and the phase angle
        /// is the angle of the phasor on the unit circle chart. The phase angle is tan^-1(imag/real)
        /// with special cases for the real portion being 0 as well as it being negative.
        /// </summary>
        /// <param name="cartesianPhasor">
        /// The phasor in cartesian form
        /// </param>
        /// <returns>
        /// The phasor in polar form where the angle is between -180 and 180 degrees
        /// </returns>
        public static PolarPhasor CartesianToPolar(CartesianPhasor cartesianPhasor)
        {
            double magnitude = Math.Sqrt(Math.Pow(cartesianPhasor.real, 2)
                + Math.Pow(cartesianPhasor.imag, 2));

            double phaseAngleDegrees = 0;
            if (magnitude > 0)
            {
                // The phasor is on the y-axis line.
                if (cartesianPhasor.real == 0)
                {
                    if (cartesianPhasor.imag > 0) phaseAngleDegrees = 90;
                    else phaseAngleDegrees = -90;
                }

                // The phasor is on the left side of the unit circle chart.
                else if (cartesianPhasor.real < 0)
                {
                    // The phasor is in the second quadrant.
                    if (cartesianPhasor.imag >= 0)
                       phaseAngleDegrees = 180 + 180 / Math.PI
                            * Math.Atan(cartesianPhasor.imag / cartesianPhasor.real);

                    // The phasor is in the third quadrant.
                    else
                        phaseAngleDegrees = -180 + 180 / Math.PI 
                            * Math.Atan(cartesianPhasor.imag / cartesianPhasor.real);
                }

                // The phasor is on the right side of the unit circle chart.
                else
                {
                    phaseAngleDegrees = 180 / Math.PI
                        * Math.Atan(cartesianPhasor.imag / cartesianPhasor.real);
                }
            }

            PolarPhasor polarPhasor = new PolarPhasor(magnitude, phaseAngleDegrees);
            return polarPhasor;
        }

        /// <summary>
        /// This method converts a polar phasor to a cartesian phasor by finding the real
        /// and imaginary parts from the magnitude and phase angle.
        /// </summary>
        /// <param name="polarPhasor">
        /// The phasor in polar form
        /// </param>
        /// <returns>
        /// The same phasor in cartesian form
        /// </returns>
        public static CartesianPhasor PolarToCartesian(PolarPhasor polarPhasor)
        {
            double real = polarPhasor.magnitude * Math.Cos(Math.PI / 180 * polarPhasor.phaseAngleDegrees);
            double imag = polarPhasor.magnitude * Math.Sin(Math.PI / 180 * polarPhasor.phaseAngleDegrees);

            CartesianPhasor cartesianPhasor = new CartesianPhasor(real, imag);
            return cartesianPhasor;
        }
    }
}
